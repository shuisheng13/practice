ActiveMQ与Spring结合-生产者端
