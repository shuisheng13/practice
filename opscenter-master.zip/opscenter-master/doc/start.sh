nohup /app/java/jdk1.8.0_202/bin/java -jar opscenter-back.jar  >> back.log 2>&1 &

