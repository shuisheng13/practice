# opscenter
数据库开发和运维平台。 
<br/>
<b>如果该项目对您有帮忙，您可以右上角'star'支持一下，谢谢！</b>
<br/>
演示地址
<br/>
👉 [http://opscenter.appjishu.com/app/index.html#/](http://opscenter.appjishu.com/app/index.html#/)
<br/>
**Star me on GitHub** 
<br/>
🐱 [https://github.com/appjishu/opscenter](https://github.com/appjishu/opscenter)
<br/>
用户名admin     密码123456
<br/>
<b>请不要在页面上修改数据</b>
<br/>
👉 [源码解析文档](SOURCE-README.md)
<br/><br/>

## 技术栈
1.Spring Boot <br/>
2.Spring-JDBC <br/>
3.activiti工作流引擎 <br/>
4.Thymeleaf <br/>
5.Vue.js <br/>
<br/>

## 未完待续

现在工作略忙，后面抽空完善技术文档。请**star此项目，以持续关注**<br/>
📌⭐⭐⭐❤❤❤ <br/>
**Star me on GitHub** <br/>

🐱[https://github.com/appjishu/opscenter](https://github.com/appjishu/opscenter) 
<br/>
演示地址
<br/>
👉 [http://opscenter.appjishu.com/app/index.html#/](http://opscenter.appjishu.com/app/index.html#/)
<br/>
用户名admin     密码123456
<br/>
<b>请不要在页面上修改数据</b><br/>
<b>如果该项目对您有帮忙，您可以右上角'star'支持一下，谢谢！</b>
<br/>
有代码改进优化的建议的可以提issue
<br/>
加群讨论，贡献代码
<br/>
![](doc/image/group-qrcode.png)
