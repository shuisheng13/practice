var welcome = {
    template:`
    <div class="subapp">
    <div class="dataarea">
        欢迎使用
    </div>
</div>
    `,data:function(){
        return {
            
        }
        },
        created:function(){
        },
        mounted:function(){
        },
        activated: function () {
        },
        methods:{
        }
};
Vue.component('welcome', welcome);
