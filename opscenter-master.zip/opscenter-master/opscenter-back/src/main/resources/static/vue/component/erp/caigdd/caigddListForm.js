var caigddListForm = {
    template: `
    	
    `,
    data:function(){
        return {
        	Calc:window.Calc,
        }
    },
    mounted:function(){
    },
    watch:{
    	
    },
    methods:{
    	
	}
}

Vue.component('caigddListForm', caigddListForm);