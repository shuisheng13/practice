var caigddListCountForm = {
    template: `
    	
    `,
    data:function(){
        return {
        	Calc:window.Calc,
        }
    },
    mounted:function(){
    },
    watch:{
    	
    },
    methods:{
    	
	}
}

Vue.component('caigddListCountForm', caigddListCountForm);