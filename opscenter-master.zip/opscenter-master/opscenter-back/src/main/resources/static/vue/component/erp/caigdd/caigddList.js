var caigddList = {
    template: `
    	
    `,
    data:function(){
        return {
        	Calc:window.Calc,
        }
    },
    mounted:function(){
    },
    watch:{
    	
    },
    methods:{
    	
	}
}

Vue.component('caigddList', caigddList);