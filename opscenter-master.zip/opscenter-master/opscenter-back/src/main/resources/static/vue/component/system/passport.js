var ureport = {
    template: `
        <div class="ureport">
		    <iframe src="/ureport/designer" class="ureport-iframe"></iframe>
		</div>
    `,
    data:function(){
        return {
           
        }
    },
    mounted:function(){
    },
    methods:{
    }
}

Vue.component('ureport', ureport);