//采购单列表
document.write('<script src="../../vue/component/erp/caigdd/caigddTitle.js"><\/script>');
//采购单查看
document.write('<script src="../../vue/component/erp/caigdd/caigddView.js"><\/script>');
//采购单表单
document.write('<script src="../../vue/component/erp/caigdd/caigddTitleForm.js"><\/script>');
//采购明细列表
document.write('<script src="../../vue/component/erp/caigdd/caigddList.js"><\/script>');
//采购明细列表
document.write('<script src="../../vue/component/erp/caigdd/caigddListForm.js"><\/script>');
//采购明细统计表单
document.write('<script src="../../vue/component/erp/caigdd/caigddListCountForm.js"><\/script>');
//采购明细统计表单
document.write('<script src="../../vue/component/erp/mm/caigdd.js"><\/script>');

