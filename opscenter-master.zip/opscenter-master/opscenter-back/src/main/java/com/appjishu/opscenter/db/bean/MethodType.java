package com.appjishu.opscenter.db.bean;

/**
 * 方法类型
 * @author  Dennie 495927@QQ.com
 * @date	 2018年11月21日 上午9:07:55
 * @version v1.0
 */
public enum MethodType {
	PROCEDURE,READONLY,TRANSITION,BATCH,MAPONLY,LISTONLY
}
