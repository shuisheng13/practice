package com.appjishu.opscenter.grid.bean;

public class PageBean {
	public int pq_curpage;
	public int pq_rpp;
}
